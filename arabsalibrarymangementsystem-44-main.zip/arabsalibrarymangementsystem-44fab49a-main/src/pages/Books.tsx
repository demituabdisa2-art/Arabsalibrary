import { useState } from "react";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { getBooks, saveBooks, generateId, type Book } from "@/lib/data";

const emptyBook: Omit<Book, "id"> = { title: "", author: "", isbn: "", category: "Primary", quantity: 1, available: 1 };

const categoryColors: Record<string, string> = {
  "Pre-Primary": "gradient-primary text-white border-0",
  "Primary": "gradient-accent text-white border-0",
  "Middle School": "gradient-warning text-white border-0",
};

const Books = () => {
  const [books, setBooks] = useState(getBooks);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Book | null>(null);
  const [form, setForm] = useState<Omit<Book, "id">>(emptyBook);

  const filtered = books.filter((b) => {
    const matchSearch = b.title.toLowerCase().includes(search.toLowerCase()) || b.author.toLowerCase().includes(search.toLowerCase());
    const matchCat = catFilter === "all" || b.category === catFilter;
    return matchSearch && matchCat;
  });

  const openAdd = () => { setEditing(null); setForm(emptyBook); setDialogOpen(true); };
  const openEdit = (b: Book) => { setEditing(b); setForm({ title: b.title, author: b.author, isbn: b.isbn, category: b.category, quantity: b.quantity, available: b.available }); setDialogOpen(true); };

  const handleSave = () => {
    if (!form.title || !form.author) { toast({ title: "Error", description: "Title and Author are required", variant: "destructive" }); return; }
    let updated: Book[];
    if (editing) {
      updated = books.map((b) => b.id === editing.id ? { ...b, ...form } : b);
      toast({ title: "Book updated" });
    } else {
      const newBook: Book = { id: generateId("B", books), ...form };
      updated = [...books, newBook];
      toast({ title: "Book added" });
    }
    setBooks(updated);
    saveBooks(updated);
    setDialogOpen(false);
  };

  const handleDelete = (id: string) => {
    const updated = books.filter((b) => b.id !== id);
    setBooks(updated);
    saveBooks(updated);
    toast({ title: "Book deleted" });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="gradient-primary rounded-xl px-6 py-4 text-white shadow-lg flex-1">
          <h1 className="text-3xl font-extrabold text-white">📚 Book Management</h1>
          <p className="text-white/80 text-sm font-medium mt-1">{books.length} books in catalog</p>
        </div>
        <Button onClick={openAdd} className="gradient-primary text-white font-bold shadow-lg hover:shadow-xl transition-all hover:scale-105 border-0 h-12 px-6">
          <Plus className="h-4 w-4 mr-2" />Add Book
        </Button>
      </div>

      <Card className="border-0 shadow-md">
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search by title or author..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Select value={catFilter} onValueChange={setCatFilter}>
              <SelectTrigger className="w-[180px]"><SelectValue placeholder="Category" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Pre-Primary">Pre-Primary</SelectItem>
                <SelectItem value="Primary">Primary</SelectItem>
                <SelectItem value="Middle School">Middle School</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Title</TableHead>
                <TableHead className="hidden md:table-cell">Author</TableHead>
                <TableHead className="hidden lg:table-cell">ISBN</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Qty</TableHead>
                <TableHead>Avail</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((b) => (
                <TableRow key={b.id} className="hover:bg-primary/5 transition-colors">
                  <TableCell className="font-mono text-xs font-bold text-primary">{b.id}</TableCell>
                  <TableCell className="font-semibold">{b.title}</TableCell>
                  <TableCell className="hidden md:table-cell">{b.author}</TableCell>
                  <TableCell className="hidden lg:table-cell text-xs">{b.isbn}</TableCell>
                  <TableCell><Badge className={categoryColors[b.category]}>{b.category}</Badge></TableCell>
                  <TableCell className="font-bold">{b.quantity}</TableCell>
                  <TableCell className={`font-bold ${b.available === 0 ? "text-destructive" : "text-accent"}`}>{b.available}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" className="hover:bg-primary/10 hover:text-primary" onClick={() => openEdit(b)}><Pencil className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="hover:bg-destructive/10" onClick={() => handleDelete(b.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-xl">{editing ? "✏️ Edit Book" : "📖 Add New Book"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2"><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
            <div className="grid gap-2"><Label>Author</Label><Input value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} /></div>
            <div className="grid gap-2"><Label>ISBN</Label><Input value={form.isbn} onChange={(e) => setForm({ ...form, isbn: e.target.value })} /></div>
            <div className="grid gap-2">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as Book["category"] })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pre-Primary">Pre-Primary</SelectItem>
                  <SelectItem value="Primary">Primary</SelectItem>
                  <SelectItem value="Middle School">Middle School</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2"><Label>Quantity</Label><Input type="number" min={0} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: +e.target.value })} /></div>
              <div className="grid gap-2"><Label>Available</Label><Input type="number" min={0} value={form.available} onChange={(e) => setForm({ ...form, available: +e.target.value })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} className="gradient-primary text-white border-0">{editing ? "Update" : "Add Book"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Books;
