import { useState } from "react";
import { Check, Search } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { getBooks, getStudents, getTransactions, saveTransactions, calculateFine, type Transaction } from "@/lib/data";

const Fines = () => {
  const students = getStudents();
  const books = getBooks();
  const [transactions, setTransactions] = useState(getTransactions);
  const [search, setSearch] = useState("");

  const fineTransactions = transactions
    .map((t) => {
      const fine = t.returnDate ? t.fineAmount : calculateFine(t.dueDate);
      return { ...t, computedFine: fine };
    })
    .filter((t) => t.computedFine > 0);

  const filtered = fineTransactions.filter((t) => {
    const student = students.find((s) => s.id === t.studentId);
    return !search || (student?.name.toLowerCase().includes(search.toLowerCase()) ?? false);
  });

  const totalPending = filtered.filter((t) => !t.finePaid).reduce((s, t) => s + t.computedFine, 0);

  const markPaid = (tx: Transaction) => {
    const updated = transactions.map((t) =>
      t.id === tx.id ? { ...t, finePaid: true, fineAmount: calculateFine(t.dueDate, t.returnDate ?? undefined) } : t
    );
    setTransactions(updated);
    saveTransactions(updated);
    toast({ title: "Fine marked as paid" });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="gradient-destructive rounded-xl px-6 py-4 text-white shadow-lg flex-1">
          <h1 className="text-3xl font-extrabold text-white">💰 Fine Management</h1>
          <p className="text-white/80 text-sm font-medium mt-1">
            Total pending: <span className="text-white font-extrabold">{totalPending} Birr</span>
          </p>
        </div>
      </div>

      <Card className="border-0 shadow-md">
        <CardHeader className="pb-3">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search by student..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
        </CardHeader>
        <CardContent>
          {filtered.length === 0 ? (
            <p className="text-muted-foreground text-sm py-8 text-center">No fines found.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Book</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Return Date</TableHead>
                  <TableHead>Fine (Birr)</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((t) => {
                  const student = students.find((s) => s.id === t.studentId);
                  const book = books.find((b) => b.id === t.bookId);
                  return (
                    <TableRow key={t.id} className="hover:bg-destructive/5 transition-colors">
                      <TableCell className="font-semibold">{student?.name}</TableCell>
                      <TableCell>{book?.title}</TableCell>
                      <TableCell>{t.dueDate}</TableCell>
                      <TableCell>{t.returnDate ?? <span className="text-destructive font-bold">Not returned</span>}</TableCell>
                      <TableCell className="font-extrabold text-destructive text-lg">{t.computedFine}</TableCell>
                      <TableCell>
                        {t.finePaid ? (
                          <Badge className="gradient-accent text-white border-0">Paid</Badge>
                        ) : (
                          <Badge className="gradient-destructive text-white border-0">Pending</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        {!t.finePaid && (
                          <Button variant="outline" size="sm" className="hover:bg-accent/10 hover:text-accent hover:border-accent" onClick={() => markPaid(t)}>
                            <Check className="h-3 w-3 mr-1" />Mark Paid
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Fines;
